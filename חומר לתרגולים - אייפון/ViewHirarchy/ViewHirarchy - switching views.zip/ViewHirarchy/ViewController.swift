//
//  ViewController.swift
//  ViewHirarchy
//
//  Created by נדב אבנון on 10/03/2021.
//

import UIKit

class ViewController: UIViewController {

    
    fileprivate let view1:UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.layer.cornerRadius = 8.0
        view.layer.borderWidth = 1.0
        view.layer.borderColor = UIColor.red.cgColor
        let label = UILabel()
        label.frame = CGRect(x: view.center.x + 17.5, y: view.center.y + 17.5, width: 70, height: 35)
        label.text = "View 2"
        label.font = label.font.withSize(12)
        label.textColor = .white
        view.addSubview(label)
        return view
    }()
    fileprivate let view2:UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .yellow
        view.layer.cornerRadius = 8.0
        view.layer.borderWidth = 1.0
        view.layer.borderColor = UIColor.red.cgColor
        let label = UILabel()
        label.frame = CGRect(x: view.center.x + 17.5, y: view.center.y + 17.5, width: 70, height: 35)
        label.text = "View 1"
        label.font = label.font.withSize(12)
        label.textColor = .black
        view.addSubview(label)
        return view
    }()
    var switchBool:Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.addSubview(view1)
        view1.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        view1.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        view1.widthAnchor.constraint(equalToConstant: 70).isActive = true
        view1.heightAnchor.constraint(equalToConstant: 70).isActive = true
       
        view.addSubview(view2)
        view2.centerYAnchor.constraint(equalTo: view1.centerYAnchor).isActive = true
        view2.centerXAnchor.constraint(equalTo: view1.centerXAnchor).isActive = true
       
        view2.widthAnchor.constraint(equalToConstant: 70).isActive = true
        view2.heightAnchor.constraint(equalToConstant: 70).isActive = true
        view1.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(doViewSwitch)))
        view2.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(doViewSwitch)))
    }
    @objc func doViewSwitch() {
        let at  = switchBool ? 1 : 0
        let with = switchBool ? 0 : 1
        let viewTo:UIView  = switchBool ? view1 : view2
    
        UIView.animate(withDuration: 0.5, delay: 0, options: []) {
            viewTo.transform = CGAffineTransform(translationX: 60, y: 20)
        } completion: { (action) in
            UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1, options: []) {[weak self] in
                self?.view.exchangeSubview(at: at, withSubviewAt: with)
                viewTo.transform = .identity
                self?.switchBool = true
            }
        }
    }
}

